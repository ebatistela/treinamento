# Dynamically Set `cds.log` Levels and Formats

### Run 

```sh
cds watch
```

### Test

Either using the UI through http://localhost:4004/loggers.html, or try the requests in `test/requests.http`
