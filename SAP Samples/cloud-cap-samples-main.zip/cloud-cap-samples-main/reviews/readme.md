# Reviews Service Sample

## Run all-in-one

Open a terminal window and run the `fiori` app in it:

```sh
npm run fiori
```


## Run as Separate Services

Open two terminal windows. In the first one start the reviews service stand-alone:

```sh
npm run reviews-service
```

In the second one start the `fiori` app:

```sh
npm run fiori
```
