const { CatalogService } = require('./srv/cat-service')
module.exports = { CatalogService }
