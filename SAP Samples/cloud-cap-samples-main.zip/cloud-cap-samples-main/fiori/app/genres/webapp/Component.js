sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], (AppComponent) =>
  AppComponent.extend("genres.Component", {
    metadata: {
      manifest: "json",
    },
  })
);
